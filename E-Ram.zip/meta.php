<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="description" content="<?= $nm_app ?> adalah aplikasi Management jual beli tandan buah segar (TBS) hasil dari perkebunan masyarakat atau petani." />
<meta name="author" content="Deny Anugrah" />
<meta name="kontak" content="082360957575" />
<meta name="whatsapp" content="https://bit.ly/whatsapp_e_ram" />