<footer class="footer bg-primary mt-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col-6 " style="text-align: start;color:black;">
                Copyright © <a href="" class="text-success"><b><?= $nm_app; ?></b></a> <?= date('Y'); ?> All Right Reserved. - Developed By <a target="_blank" class="text-success" href="https://api.whatsapp.com/send?phone=6282360957575&text=Saya%20ingin%20menanyakan%20seputaran%20aplikasi%20E-RAM%20!">Deny Anugrah</a>
            </div>
            <div class="col-6 " style="text-align: end;color:black;">
                Versi <?= $versi; ?>
            </div>
        </div>
    </div>
</footer>